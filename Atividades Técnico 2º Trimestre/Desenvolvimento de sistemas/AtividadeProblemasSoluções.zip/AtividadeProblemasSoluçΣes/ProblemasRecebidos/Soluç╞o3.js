//Criar lista de compras (Isadora)

const itensMercado = [ {
    nome: "Leite ninho",
    quantidade: "4 latas"
},  
{
    nome: "Café",
    quantidade: "2 pacotes",
},
{  
    nome: "Detergente",
    quantidade: "3 frascos"
},  
{
    nome: "Creme dental",
    quantidade: "2 unidades"
},
{
    nome: "Fio dental",
    quantidade: "2 unidades"
},
{
    nome: "Creme de cabelo",
    quantidade: "2 unidades"
},
{
    nome: "Morangos",
    quantidade: "5 bandejas"
},
{
    nome: " Uvas",
    quantidade: "3 bandejas"
},
{
    nome: "Sabonete em pó",
    quantidade: "1 unidade"
},
{
    nome: "Carne moída",
    quantidade: "1kg"
},
{
    nome: "Cebola",
    quantidade: "2kg"
},
{
    nome: "Cenoura",
    quantidade: "1 kg"
},
{
    nome: "Tomate",
    quantidade: "2 kg"
},
{
    nome: "Arroz",
    quantidade: "1 kg"
},
{
    nome: "Sal",
    quantidade: "250g"
},
{
    nome: "Acuçar",
    quantidade: "1 kg"
},
{
    nome: "Ovos",
    quantidade: "2 bandejas"
},
{
    nome: "Frango",
    quantidade: "3kg"
},
{
    nome: "Bife",
    quantidade: "2kg"
}
]
console.log(itensMercado)