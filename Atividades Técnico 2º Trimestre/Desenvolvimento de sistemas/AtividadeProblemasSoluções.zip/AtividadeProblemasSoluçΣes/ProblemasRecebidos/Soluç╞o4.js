// Média das provas (Beatriz)

var Provas = {
    n1: 6,
    n2: 6,
    n3: 6
}

function soma (){
    return (Provas.n1 + Provas.n2 + Provas.n3)
}

function divisão (){
    return (soma()/3)
}


console.log("A média do(a) aluno(a) das 3 primeiras provas é " + divisão())