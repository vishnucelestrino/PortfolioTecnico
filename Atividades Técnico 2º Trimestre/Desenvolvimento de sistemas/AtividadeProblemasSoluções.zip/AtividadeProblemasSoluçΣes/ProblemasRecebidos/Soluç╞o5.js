//Valor da compra com desconto (Bia)

const Compra = {
    valorCompra: 200,
    porcentagemDesconto: 10
}

function descontop (){
    return (Compra.porcentagemDesconto/100)
}
function descontov (){
    return (Compra.valorCompra*descontop())
}
function total (){
    return (Compra.valorCompra-descontov())
}

console.log("O total de sua compra com desconto deu " +total()+ " reais.")