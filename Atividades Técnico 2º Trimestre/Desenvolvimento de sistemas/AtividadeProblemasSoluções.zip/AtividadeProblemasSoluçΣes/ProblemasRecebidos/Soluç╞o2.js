//Lista para Banheiro e Dúvidas 3c (Vishnu)

{
    Array 
    const banheiro = ["aluno1", "aluno2", "aluno3", "aluno4"]
    console.log(banheiro)
    }
    
    {
    Array 
    const duvidas = ["aluno1", "aluno2", "aluno3", "aluno4"]
    console.log(duvidas)
    }
