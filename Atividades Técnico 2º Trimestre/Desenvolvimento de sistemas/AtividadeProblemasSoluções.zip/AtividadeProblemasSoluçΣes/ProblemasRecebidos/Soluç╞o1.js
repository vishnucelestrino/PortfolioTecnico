//buscar livros por gênero (palú)

const livros = [
    {
        titulo: "Tudo começou com maquiavel",
        autor: "Luciano Gruppi",
        genero: "Política",
        descrição: "Este livro é uma rara combinação do rigor científico no exame do surgimento e da consolidação do Estado moderno com um texto enxuto, de leitura extremamente agradável."
    },
    {
        titulo: "O menino do pijama listrado",
        autor: "John Boyne",
        genero: "Ação",
        descricao: "Uma triste história que se passa no período da segunda guerra mundial."
    },
    {
        titulo: "Jogos vorazes",
        autor: "Suzanne Collins",
        genero: "Ação",
        descricao: "É a manhã do dia da colheita que iniciará a décima edição dos Jogos Vorazes. Na Capital, o jovem de dezoito anos Coriolanus Snow se prepara para sua oportunidade de glória como um mentor dos Jogos."
    }
]

function buscar (genero){
    for (let i = 0; i < livros.length; i++){
        if(livros[i].genero == genero){
            console.log(livros[i])
        }
    }    
}
buscar("Ação")
