// Problema Ana e Danilo (Bia)

var anoAtual = 2023
const Aluno = {
    nome: 'Beatriz',
    anoNascimento: 2006
}
function MaiorIdade() {
    if ( anoAtual - Aluno.anoNascimento < 18){
       console.log('O(a) Aluno(a) '+ Aluno.nome + ' é menor de idade.')
    }
    else{
        console.log('O(a) Aluno(a) '+ Aluno.nome + ' é maior de idade.')
    }
}

MaiorIdade()