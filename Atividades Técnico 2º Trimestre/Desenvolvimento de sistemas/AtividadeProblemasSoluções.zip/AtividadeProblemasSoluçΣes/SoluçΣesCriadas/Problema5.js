//Problema Paulo (Vishnu)

const vendidosdia30 = [
    {
        nome: "Celular",
        marca: "Motorola",
        preco: 2000,
        quantidade: 1
    },
    {
        nome: "Fone Bluetooth",
        marca: "JBL",
        preco: 300,
        quantidade: 1
    },
    {
        nome: "Carregador Celular",
        marca: "Kaidi",
        preco: 30,
        quantidade: 2
    },
    {
        nome: "Caixa de Som",
        marca: "JBL",
        preco: 900.50,
        quantidade: 1
    },
    {
        nome: 'Fone de ouvido com fio',
        marca: "SoundOn",
        preco: 15,
        quantidade: 5
    },
    {
        nome: "Celular",
        marca: "Apple",
        preco: 4300.89,
        quantidade: 1
    }
    ]
console.log (vendidosdia30)