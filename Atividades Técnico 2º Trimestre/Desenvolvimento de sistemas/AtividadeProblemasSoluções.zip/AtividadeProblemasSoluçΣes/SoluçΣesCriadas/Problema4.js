//Problema Juliana (Vishnu)

Array 
const listadecompras = ["arroz", "feijão", "sal", "fermento", "amaciante", "sabonete", "detergente"]
console.log(listadecompras[3])