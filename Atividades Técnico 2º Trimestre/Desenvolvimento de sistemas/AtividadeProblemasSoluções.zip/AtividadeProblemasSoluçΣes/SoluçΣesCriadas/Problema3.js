//Problema Fileira da frente (Isadora)

const infDoces = [ {
    nome: "brigadeiro",
    preçodaunidade: "3",
    sabor: "chocolate",
    quantidade: "50",
    tempodepreparo: "40min"




},  
{
    nome: "cocadinha de padaria",
    preçodaunidade:"4",
    sabor: "coco",
    quantidade: "10",
    tempodepreparo: "30min"
},
{  
    nome: "beliscão de goiabada",
    preçodaunidade:"5",
    sabor: "goiaba",
    quantidade: "6",
    tempodepreparo: "40min"




},  
{
    nome: "sonho",
    preçodaunidade:"5",
    sabor: "creme",
    quantidade: "20",
    tempodepreparo: "2 horas"
},
{
    nome: " bolo de chocolate",
    preçodaunidade:"30",
    sabor: "chocolate",
    quantidade: "6",
    tempodepreparo: "1 hora"
}
]
console.log(infDoces)