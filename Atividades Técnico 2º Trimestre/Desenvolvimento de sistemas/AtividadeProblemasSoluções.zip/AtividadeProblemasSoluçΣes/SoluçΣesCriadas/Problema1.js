// Pizzaria Luca (Palú)

// As notas estão na mesma ordem dos perfis
const socio1 = [5, 8, 10, 9, 8, 5]
const socio2 = [6, 7, 10, 9, 10, 7]
const socio3 = [4, 6, 10, 9, 6, 6]

const media0 = (socio1[0]+socio2[0]+socio3[0])/3
const media1 = (socio1[1]+socio2[1]+socio3[1])/3
const media2 = (socio1[2]+socio2[2]+socio3[2])/3
const media3 = (socio1[3]+socio2[3]+socio3[3])/3
const media4 = (socio1[4]+socio2[4]+socio3[4])/3
const media5 = (socio1[5]+socio2[5]+socio3[5])/3

const perfis = [
    {
        nome: "Cássia",
        avaliacao: media0
    },
    {
        nome: "Roberto",
        avaliacao: media1
    },
    {
        nome: "Luca",
        avaliacao: media2
    },
    {
        nome: "Vanessa",
        avaliacao: media3
    },
    {
        nome: "Beatriz",
        avaliacao: media4
    },
    {
        nome: "Paulo",
        avaliacao: media5
    }
]
console.log(perfis)